# Get Payout Status

```bash
GET /order/get
```
Use this API to get the list of items for a single order.

## Common Parameters
---
#### Service Endpoints