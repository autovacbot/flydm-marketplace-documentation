export default [
  require('C:\\Users\\USER\\Lazada-Api\\Lazada-Api\\node_modules\\infima\\dist\\css\\default\\default.css'),
  require('C:\\Users\\USER\\Lazada-Api\\Lazada-Api\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages'),
  require('C:\\Users\\USER\\Lazada-Api\\Lazada-Api\\node_modules\\@docusaurus\\theme-classic\\lib\\admonitions.css'),
  require('C:\\Users\\USER\\Lazada-Api\\Lazada-Api\\node_modules\\@docusaurus\\theme-classic\\lib\\nprogress'),
  require('C:\\Users\\USER\\Lazada-Api\\Lazada-Api\\src\\css\\custom.css'),
];
