import React from 'react';
import ComponentCreator from '@docusaurus/ComponentCreator';

export default [
  {
    path: '/__docusaurus/debug',
    component: ComponentCreator('/__docusaurus/debug', 'cd6'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/config',
    component: ComponentCreator('/__docusaurus/debug/config', 'ace'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/content',
    component: ComponentCreator('/__docusaurus/debug/content', '8dd'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/globalData',
    component: ComponentCreator('/__docusaurus/debug/globalData', '043'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/metadata',
    component: ComponentCreator('/__docusaurus/debug/metadata', 'be3'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/registry',
    component: ComponentCreator('/__docusaurus/debug/registry', '2c4'),
    exact: true
  },
  {
    path: '/__docusaurus/debug/routes',
    component: ComponentCreator('/__docusaurus/debug/routes', '8a4'),
    exact: true
  },
  {
    path: '/blog',
    component: ComponentCreator('/blog', '71f'),
    exact: true
  },
  {
    path: '/blog/archive',
    component: ComponentCreator('/blog/archive', '281'),
    exact: true
  },
  {
    path: '/blog/first-blog-post',
    component: ComponentCreator('/blog/first-blog-post', 'e05'),
    exact: true
  },
  {
    path: '/blog/long-blog-post',
    component: ComponentCreator('/blog/long-blog-post', 'd70'),
    exact: true
  },
  {
    path: '/blog/mdx-blog-post',
    component: ComponentCreator('/blog/mdx-blog-post', 'c1d'),
    exact: true
  },
  {
    path: '/blog/tags',
    component: ComponentCreator('/blog/tags', 'bc7'),
    exact: true
  },
  {
    path: '/blog/tags/docusaurus',
    component: ComponentCreator('/blog/tags/docusaurus', '75e'),
    exact: true
  },
  {
    path: '/blog/tags/facebook',
    component: ComponentCreator('/blog/tags/facebook', 'b46'),
    exact: true
  },
  {
    path: '/blog/tags/hello',
    component: ComponentCreator('/blog/tags/hello', 'eb4'),
    exact: true
  },
  {
    path: '/blog/tags/hola',
    component: ComponentCreator('/blog/tags/hola', 'e54'),
    exact: true
  },
  {
    path: '/blog/welcome',
    component: ComponentCreator('/blog/welcome', '9b2'),
    exact: true
  },
  {
    path: '/markdown-page',
    component: ComponentCreator('/markdown-page', '01c'),
    exact: true
  },
  {
    path: '/my-react-page',
    component: ComponentCreator('/my-react-page', '118'),
    exact: true
  },
  {
    path: '/docs',
    component: ComponentCreator('/docs', '3be'),
    routes: [
      {
        path: '/docs/category/new-order',
        component: ComponentCreator('/docs/category/new-order', 'c9d'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/category/order-update-status',
        component: ComponentCreator('/docs/category/order-update-status', '2a0'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/category/tutorial---basics',
        component: ComponentCreator('/docs/category/tutorial---basics', 'd44'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/category/tutorial---extras',
        component: ComponentCreator('/docs/category/tutorial---extras', 'f09'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/intro',
        component: ComponentCreator('/docs/intro', 'aed'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/New Order/Get Document',
        component: ComponentCreator('/docs/New Order/Get Document', '9f8'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/New Order/Get Document PDF',
        component: ComponentCreator('/docs/New Order/Get Document PDF', '08c'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/New Order/Get Order',
        component: ComponentCreator('/docs/New Order/Get Order', 'c26'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/New Order/Get Order Items',
        component: ComponentCreator('/docs/New Order/Get Order Items', '3be'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/New Order/Get Orders',
        component: ComponentCreator('/docs/New Order/Get Orders', 'd25'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/New Order/Get Payout Status',
        component: ComponentCreator('/docs/New Order/Get Payout Status', '855'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/New Order/Get Product Review List',
        component: ComponentCreator('/docs/New Order/Get Product Review List', 'bbe'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/New Order/Get Products',
        component: ComponentCreator('/docs/New Order/Get Products', '3b0'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/New Order/Get Products Item',
        component: ComponentCreator('/docs/New Order/Get Products Item', '49c'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/New Order/Get Reverse Order Detail',
        component: ComponentCreator('/docs/New Order/Get Reverse Order Detail', 'ad1'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/New Order/Get Reverse Order For Seller',
        component: ComponentCreator('/docs/New Order/Get Reverse Order For Seller', '2b8'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/New Order/Get Reverse Order History List',
        component: ComponentCreator('/docs/New Order/Get Reverse Order History List', 'be1'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/New Order/Get Reverse Order Reason List',
        component: ComponentCreator('/docs/New Order/Get Reverse Order Reason List', 'f14'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/New Order/Get Seller Metrics By ID',
        component: ComponentCreator('/docs/New Order/Get Seller Metrics By ID', 'c24'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/New Order/Get Seller Performance',
        component: ComponentCreator('/docs/New Order/Get Seller Performance', '4ee'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/New Order/Get Shipment Providers',
        component: ComponentCreator('/docs/New Order/Get Shipment Providers', 'a04'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/New Order/Get Transaction Details',
        component: ComponentCreator('/docs/New Order/Get Transaction Details', '62c'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/New Order/Query Transaction Details',
        component: ComponentCreator('/docs/New Order/Query Transaction Details', 'dad'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/New Order/Reverse Order Return Update',
        component: ComponentCreator('/docs/New Order/Reverse Order Return Update', '68f'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/New Order/Set order status to canceled',
        component: ComponentCreator('/docs/New Order/Set order status to canceled', '262'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/New Order/Set order status to Packed',
        component: ComponentCreator('/docs/New Order/Set order status to Packed', '216'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/New Order/Set order status to Ready to Ship',
        component: ComponentCreator('/docs/New Order/Set order status to Ready to Ship', 'ca9'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/New Order/Set SOF order status to being delivered',
        component: ComponentCreator('/docs/New Order/Set SOF order status to being delivered', '2f3'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/New Order/Submit Seller Reply',
        component: ComponentCreator('/docs/New Order/Submit Seller Reply', '7b0'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/New Order/Update Price Quantity',
        component: ComponentCreator('/docs/New Order/Update Price Quantity', '0d4'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/New Order/Voucher Activate',
        component: ComponentCreator('/docs/New Order/Voucher Activate', '22b'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/New Order/Voucher Create',
        component: ComponentCreator('/docs/New Order/Voucher Create', '604'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/New Order/Voucher Deactivate',
        component: ComponentCreator('/docs/New Order/Voucher Deactivate', '474'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/New Order/Voucher Detail query',
        component: ComponentCreator('/docs/New Order/Voucher Detail query', '260'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/New Order/Voucher List',
        component: ComponentCreator('/docs/New Order/Voucher List', 'ae2'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/Order Update Status/Get Payout Status',
        component: ComponentCreator('/docs/Order Update Status/Get Payout Status', '68a'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/tutorial-basics/congratulations',
        component: ComponentCreator('/docs/tutorial-basics/congratulations', '793'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/tutorial-basics/create-a-blog-post',
        component: ComponentCreator('/docs/tutorial-basics/create-a-blog-post', '68e'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/tutorial-basics/create-a-document',
        component: ComponentCreator('/docs/tutorial-basics/create-a-document', 'c2d'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/tutorial-basics/create-a-page',
        component: ComponentCreator('/docs/tutorial-basics/create-a-page', 'f44'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/tutorial-basics/deploy-your-site',
        component: ComponentCreator('/docs/tutorial-basics/deploy-your-site', 'e46'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/tutorial-basics/markdown-features',
        component: ComponentCreator('/docs/tutorial-basics/markdown-features', '4b7'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/tutorial-extras/manage-docs-versions',
        component: ComponentCreator('/docs/tutorial-extras/manage-docs-versions', 'fdd'),
        exact: true,
        sidebar: "tutorialSidebar"
      },
      {
        path: '/docs/tutorial-extras/translate-your-site',
        component: ComponentCreator('/docs/tutorial-extras/translate-your-site', '2d7'),
        exact: true,
        sidebar: "tutorialSidebar"
      }
    ]
  },
  {
    path: '/',
    component: ComponentCreator('/', 'e29'),
    exact: true
  },
  {
    path: '*',
    component: ComponentCreator('*'),
  },
];
